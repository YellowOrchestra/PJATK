/**
 *
 *  @author Maj Krzysztof S18533
 *
 */

package zad1;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main {
  static List<Towar> listaTowarow = new ArrayList<>();
  static File towary = new File("../Towary.txt");
  static TowarUtility util = new TowarUtility(listaTowarow, towary);
  public static void main(String[] args) {
    Thread A = new Thread(() ->{
      try{
        util.readTowar();
      }catch(IOException e){
        e.printStackTrace();
      }
    });

    Thread B = new Thread(() ->{
      util.sumTowar();
    });

    A.start();
    B.start();
  }
}
