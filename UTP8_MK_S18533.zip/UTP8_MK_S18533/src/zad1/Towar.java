package zad1;

public class Towar {
    int idTowar;
    double waga;

    public Towar(int id, double wg){
        idTowar = id;
        waga = wg;
    }

    public Towar(int id){
        idTowar = id;
        waga = 0.0;
    }

    public Towar(double wg){
        idTowar = 0;
        waga = wg;
    }

    public Towar(){
        idTowar = 0;
        waga = 0.0;
    }
}
