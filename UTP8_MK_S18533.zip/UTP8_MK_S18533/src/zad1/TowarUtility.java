package zad1;

import java.io.*;
import java.util.List;

public class TowarUtility {
    boolean nextTowar = true;
    List<Towar> list;
    BufferedReader bufferedReader;
    Double sum = 0.0;

    public TowarUtility(List<Towar> l, File f){
        list = l;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } ;
    }

    public synchronized void readTowar() throws IOException{
        Towar tmp;
        String towar_dane;
        String[] idWaga;
        while((towar_dane = bufferedReader.readLine()) != null){
            while (!nextTowar) {
                try {
                    wait();
                } catch(InterruptedException exc) {

                }
            }
            nextTowar = false;
            notifyAll();
            idWaga = towar_dane.split(" ");
            tmp = new Towar(Integer.parseInt(idWaga[0]),Double.parseDouble(idWaga[1]));
            //System.out.println("czytam");
            list.add(tmp);
            if(list.size() % 200 == 0){
                System.out.println("utworzono " + list.size() + " obiektów");
            }
        }

        try {
            wait();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        nextTowar = false;
        notifyAll();
    }

    public synchronized void sumTowar(){
        Towar next;
        Towar last = null;
        while(true) {
            while (nextTowar || list.size() == 0) {
                try {
                    wait();
                } catch (InterruptedException exc) {

                }
            }
            nextTowar = true;
            notifyAll();
            next = list.get(list.size()-1);
            if(next == last){
                break;
            }
            last = next;
            sum += next.waga;
            //System.out.println("zsumowalem");
            if(list.size() % 100 == 0){
                System.out.println("policzono wage " + list.size() + " obiektów");
            }
        }
        System.out.println(sum);
    }
}
